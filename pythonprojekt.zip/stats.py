egeszseg = 10
energia = 10
lebukas = 0
penz = 100




def print_stats():
    print('-------------------------------')
    print(f'HP: \t\t\t{egeszseg}/10')
    print(f'Energia: \t\t{energia}/10')
    print(f'Lebukás esélye: \t{lebukas}/10')
    print(f'Pénzed: \t\t{penz}Ft')
    print('-------------------------------')

def line():
    print('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
