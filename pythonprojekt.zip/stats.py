egeszseg = 10
energia = 10
lebukas = 0 
penz = 100

def stat(egeszseg,energia,lebukas,penz):
    print(f'HP: {egeszseg}/10')
    print(f'Energia: {energia}/10')
    print(f'Lebukás esélye: {lebukas}/10')
    print(f'Pénzed: {penz} Ft')

stat(egeszseg,energia,lebukas,penz)